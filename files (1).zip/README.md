# Safety Management Dashboard

ระบบบริหารจัดการงานความปลอดภัยโรงพยาบาล (Hospital Safety Management System)
พัฒนาให้กับ **โรงพยาบาลเปาโล เกษตร**

Live prototype แบบ Single Page Application ที่ครอบคลุมงานด้านความปลอดภัยของโรงพยาบาลทั้งหมด
ตั้งแต่ Zero Accident, Safety Round, ตัวชี้วัด KPI (รวม IFR/ISR), การจัดการขยะ, คุณภาพน้ำเสีย,
การอบรมพนักงาน/ผู้รับเหมา, ทะเบียนเจ้าหน้าที่ความปลอดภัย, ผลตรวจประเมิน, ระบบติดตามการแก้ไข (CAPA),
ศูนย์รายงาน, การแจ้งเตือน และการจัดการสิทธิ์ผู้ใช้งาน

## เทคโนโลยีที่ใช้

โปรเจกต์นี้เป็น **Vanilla JavaScript** ล้วน ไม่มี framework และไม่มี build step:

| ส่วนประกอบ | เทคโนโลยี |
|---|---|
| Markup | HTML5 |
| Logic | JavaScript (ES6+) — ไม่มี React / Vue / TypeScript |
| Styling | CSS3 (CSS Custom Properties สำหรับ Light/Dark theme) |
| กราฟ | [Chart.js 4.4.1](https://www.chartjs.org/) โหลดผ่าน CDN |
| ฟอนต์ | Google Fonts — IBM Plex Sans Thai |
| การเก็บข้อมูล | `localStorage` ของเบราว์เซอร์ (ข้อมูลตัวอย่างถูก seed ไว้ในโค้ด) |
| Build tool | ไม่มี — ไม่ต้อง `npm install` ก็รันได้ทันที |

> **หมายเหตุ:** เวอร์ชันนี้เป็น Front-end prototype ที่เก็บข้อมูลใน `localStorage` ของเบราว์เซอร์
> แต่ละเครื่อง ข้อมูลจึงไม่ sync ข้ามผู้ใช้/เครื่อง หากต้องการใช้งานจริงในองค์กร
> ต้องเชื่อมต่อกับ REST API และฐานข้อมูลจริง (ดูหัวข้อ "แนวทางต่อยอดเป็นระบบใช้งานจริง" ด้านล่าง)

## โครงสร้างโปรเจกต์

```
safety-management-dashboard/
├── index.html          หน้าเว็บหลัก (markup + การอ้างอิงไฟล์ CSS/JS)
├── css/
│   └── styles.css      สไตล์ทั้งหมดของระบบ (layout, components, dark mode)
├── js/
│   └── app.js           โค้ด JavaScript ทั้งหมด (ข้อมูล, state, views, router)
├── README.md            เอกสารนี้
├── package.json          ข้อมูลโปรเจกต์ + สคริปต์รัน local dev server
├── .gitignore
├── LICENSE
├── netlify.toml          คอนฟิกสำหรับ deploy บน Netlify (ถ้าใช้)
└── vercel.json           คอนฟิกสำหรับ deploy บน Vercel (ถ้าใช้)
```

## วิธีรันโปรเจกต์ในเครื่อง (Local Development)

ไม่ต้องติดตั้งอะไรก็เปิดใช้งานได้ทันที เพราะเป็น static HTML/CSS/JS ธรรมดา:

**วิธีที่ 1 — เปิดไฟล์ตรง ๆ**
```
เปิดไฟล์ index.html ด้วยเบราว์เซอร์ได้เลย
```

**วิธีที่ 2 — รันผ่าน local server (แนะนำ เพื่อไม่ให้ path มีปัญหา)**
```bash
# ใช้ Node.js (ต้องติดตั้ง Node.js ก่อน)
npx serve .

# หรือใช้ Python
python3 -m http.server 8000
```
จากนั้นเปิดเบราว์เซอร์ไปที่ `http://localhost:8000` (หรือ port ที่ serve แจ้ง)

## วิธี Deploy ขึ้น Hosting

โปรเจกต์นี้เป็น Static Site จึง deploy ได้กับทุก static hosting โดยไม่ต้องมี build step:

### GitHub Pages
1. Push โค้ดนี้ขึ้น repository บน GitHub
2. ไปที่ Settings → Pages → Source เลือก branch `main` และโฟลเดอร์ `/ (root)`
3. รอสักครู่แล้วเข้าใช้งานได้ที่ `https://<username>.github.io/<repo-name>/`

### Netlify / Vercel
1. เชื่อมต่อ repository เข้ากับ Netlify หรือ Vercel
2. Build command: ปล่อยว่างไว้ (ไม่มี build step)
3. Publish/Output directory: `.` (root)

### Web server ทั่วไป (Nginx / Apache / IIS)
คัดลอกไฟล์ทั้งหมดในโปรเจกต์ไปยัง document root ของเว็บเซิร์ฟเวอร์ได้โดยตรง

## Dependency ภายนอกที่ต้องเข้าถึงอินเทอร์เน็ตได้

แอปนี้โหลด 2 อย่างจาก CDN ภายนอก — หากองค์กรบล็อกการเข้าถึง CDN
ต้อง self-host ไฟล์เหล่านี้แทน:

1. `https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js`
2. `https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Thai...` (และไฟล์ฟอนต์จาก `fonts.gstatic.com`)

## แนวทางต่อยอดเป็นระบบใช้งานจริง

ระบบถูกออกแบบสถาปัตยกรรมไว้ในหน้า "โครงสร้างฐานข้อมูล" ภายในแอป โดยชั้นข้อมูลทั้งหมด
เข้าถึงผ่านอ็อบเจกต์ `Store` เพียงจุดเดียวใน `js/app.js` (เมธอด `Store.load()` / `Store.save()`)
การเปลี่ยนจาก `localStorage` ไปเป็น REST API จริงทำได้โดยแก้เฉพาะสองเมธอดนี้ให้เรียก `fetch()`
ไปยัง backend แทน โดยไม่ต้องแก้ไข views หรือ UI logic ส่วนอื่น

ฐานข้อมูลเชิงสัมพันธ์ที่แนะนำมี 18 ตารางหลัก (users, departments, accidents, safety_rounds,
kpis, waste_records, wastewater_records, inspections, trainings, safety_officers,
corrective_actions, notifications, documents ฯลฯ) ดูรายละเอียดคอลัมน์และความสัมพันธ์ทั้งหมด
ได้ในหน้า "โครงสร้างฐานข้อมูล" ของแอป

## License

MIT — ดูไฟล์ [LICENSE](./LICENSE)
